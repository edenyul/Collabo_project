package z;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

public class Main extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JButton btnCash, btnCard;
	private static Main frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.SOUTH);
		
		btnCash = new JButton("\uD604\uAE08 \uACB0\uC81C");
		panel.add(btnCash);
		
		btnCard = new JButton("\uCE74\uB4DC\uACB0\uC81C");
		panel.add(btnCard);
		
		btnCard.addActionListener(this);
		btnCash.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton b = (JButton) e.getSource();
		
		Cash c = new Cash();
		c.setMainF(frame);
		Card d = new Card();
		
		if(b==btnCash) {
			c.setVisible(true);
		}else {
			d.setVisible(true);
		}
		
		/*if(c.sayhow()==true) {
			System.out.println("���� ���� true");
			System.out.println(c.sayhow());
			System.out.println("=========================");
			dispose();
		}else {
			System.out.println("���� ���� false");
			System.out.println(c.sayhow());
			System.out.println("+++++++++++++++++++++++");
		}*/
		
	}

}
