package test;

import java.io.File;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

public class Sound {

	public static void main(String[] args) {
		 try

		 {

		 AudioInputStream ais = AudioSystem.getAudioInputStream(new File("../test/Danger.mp3"));

		Clip clip = AudioSystem.getClip();

		clip.stop();

		clip.open(ais);

		clip.start();

		 }

		 catch (Exception ex)

		 {

		  } 

	}

}
