package z;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Card extends JDialog implements ActionListener{

	private final JPanel contentPanel = new JPanel();
	private JButton okButton, cancelButton;
	public boolean say;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Card dialog = new Card();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Card() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
	}//end ������

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton bb=(JButton) e.getSource();
		
		if(bb==okButton) {
			System.out.println("���� ���̾�α� Ȯ�� ����");
			say=true;
			sayhow();
			JOptionPane.showConfirmDialog(this, "���� �Ϸ�", "���� �Ϸ�", JOptionPane.CLOSED_OPTION, JOptionPane.INFORMATION_MESSAGE);
			dispose();
		}else if(bb==cancelButton){
			System.out.println("���� ���̾�α� ��� ����");
			say=false;
			sayhow();
			dispose();
		}
		
	}//end action
	
	public boolean sayhow() {
		return say;
	}

}
