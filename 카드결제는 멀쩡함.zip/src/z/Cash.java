package z;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Cash extends JDialog implements ActionListener{

	private final JPanel contentPanel = new JPanel();
	private JFrame mainF;
	private JButton okButton, cancelButton;
	public boolean say;

	
	public void setMainF(JFrame mainF) {
		this.mainF = mainF;
	}
	public JFrame getMainF() {
		return mainF;
	}
	
	
	public static void main(String[] args) {
		try {
			Cash dialog = new Cash();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Cash() {
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new FlowLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				okButton = new JButton("OK");
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				cancelButton = new JButton("Cancel");
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}
		
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
	}//end ������

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton bb=(JButton) e.getSource();
		
		if(bb==okButton) {
			System.out.println("���� ���̾�α� Ȯ�� ����");			
			
			JOptionPane.showConfirmDialog(this, "���� �Ϸ�", "���� �Ϸ�", JOptionPane.CLOSED_OPTION, JOptionPane.INFORMATION_MESSAGE);
			JFrame main=getMainF();
			main.dispose();
			dispose();
		}else if(bb==cancelButton){
			System.out.println("���� ���̾�α� ��� ����");
			say=false;
			sayhow();
			dispose();
		}
	}//end action
	
	public boolean sayhow() {
		say=true;
		return say;
	}

}
